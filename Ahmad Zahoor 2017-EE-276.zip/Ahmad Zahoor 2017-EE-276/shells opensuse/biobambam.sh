wget https://github.com/gt1/biobambam/archive/master.zip
