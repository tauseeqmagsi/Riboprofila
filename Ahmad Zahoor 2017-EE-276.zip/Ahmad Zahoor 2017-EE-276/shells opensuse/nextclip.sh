wget https://github.com/richardmleggett/nextclip/archive/master.zip
