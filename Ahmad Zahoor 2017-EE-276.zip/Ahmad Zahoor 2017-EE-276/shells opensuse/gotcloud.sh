wget https://github.com/statgen/gotcloud/archive/master.zip
