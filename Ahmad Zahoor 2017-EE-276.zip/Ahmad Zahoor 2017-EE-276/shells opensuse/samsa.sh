wget https://github.com/transcript/SAMSA/archive/master.zip
