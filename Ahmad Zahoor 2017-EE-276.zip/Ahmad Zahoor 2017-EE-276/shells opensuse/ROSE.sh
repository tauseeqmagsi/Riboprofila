wget ps://github.com/metomi/rose/archive/master.zip

