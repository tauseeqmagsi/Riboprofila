wget https://github.com/xryanglab/xtail/archive/master.zip
