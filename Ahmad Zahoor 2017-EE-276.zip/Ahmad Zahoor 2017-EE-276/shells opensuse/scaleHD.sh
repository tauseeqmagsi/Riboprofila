wget https://github.com/helloabunai/ScaleHD/archive/master.zip
