#! /bin/bash

git clone https://github.com/richardmleggett/nextclip.git
