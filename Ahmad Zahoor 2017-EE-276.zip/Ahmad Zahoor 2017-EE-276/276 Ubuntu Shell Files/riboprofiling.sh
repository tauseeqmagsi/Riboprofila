#! /bin/bash

git clone https://github.com/Arthurhe/Riboprofiling_pipeline_Arthur.git

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base
sudo -i R


>devtools::install_github('Arthurhe/Riboprofiling_pipeline_Arthur')
