#! /bin/bash

git clone https://github.com/gt1/biobambam.git

sudo install Libmaus
make install Biobambam
