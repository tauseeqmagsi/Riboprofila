#! /bin/bash

git clone https://github.com/rcallahan/smalt.git

make install smalt 
