#! /bin/bash

git clone https://github.com/helloabunai/ScaleHD.git

sudo apt-get update
sudo apt install python
sudo apt install python pip
pip install numpy
pip install scipy
pip install scikit-learn
sudo python setup.py install

pip install ScaleHD

