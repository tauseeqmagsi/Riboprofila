#! /bin/bash

git clone https://github.com/transcript/SAMSA.git

sudo apt-get update
sudo apt install python
sudo apt install python pip
pip install numpy
pip install scipy
pip install scikit-learn
sudo python setup.py install

sudo !! 
sudo Rscript package_ install . Rmd 
