#! /bin/bash

git clone https://github.com/jhhung/PEAT.git

available in package as its linux file i.e PEAT.linux
