#! /bin/bash

git clone https://github.com/GregoryFaust/samblaster.git

sudo apt-get install g++
cd source 
make 

sudo make SAMBLASTER

