#! /bin/bash

git clone https://github.com/biopet/bamstats.git
