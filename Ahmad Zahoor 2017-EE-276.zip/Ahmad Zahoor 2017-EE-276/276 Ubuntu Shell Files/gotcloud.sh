#! /bin/bash

git clone https://github.com/statgen/gotcloud.git
