#! /bin/bash

git clone https://github.com/alessandroleite/docker-segemehl.git

sudo cp docker-segemhl /opt/
