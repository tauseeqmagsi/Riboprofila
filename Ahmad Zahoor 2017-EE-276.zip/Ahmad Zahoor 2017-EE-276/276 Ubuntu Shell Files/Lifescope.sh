#! /bin/bash

git clone https://github.com/LifeScopeLabs/lifescope-xr.git
