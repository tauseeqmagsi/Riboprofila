wget https://github.com/jfromaniello/xtail/archive/master.zip
