wget https://github.com/kundajelab/phantompeakqualtools/archive/master.zip
