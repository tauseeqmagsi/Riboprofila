wget https://github.com/cbg-ethz/V-pipe/archive/master.zip
