wget https://github.com/metomi/rose/archive/master.zip
