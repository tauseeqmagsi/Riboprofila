wget https://github.com/OpenGene/AfterQC/archive/master.zip
