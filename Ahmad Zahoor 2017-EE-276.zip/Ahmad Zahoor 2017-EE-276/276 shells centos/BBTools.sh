wget https://github.com/kbaseapps/BBTools/archive/master.zip
