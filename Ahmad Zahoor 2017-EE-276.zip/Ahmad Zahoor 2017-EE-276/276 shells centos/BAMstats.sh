wget https://github.com/biopet/bamstats/archive/develop.zip
