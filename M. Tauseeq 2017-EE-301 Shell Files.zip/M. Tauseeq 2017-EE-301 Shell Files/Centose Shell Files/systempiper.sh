#! bin/bash

#Installation and Downloading of systemPiper

#The software in R language downloads and installs at a time.

#Installation of R language--- This should be done when you are installing any R language tool for the first time

git clone https://github.com/tgirke/systemPipeR.git
