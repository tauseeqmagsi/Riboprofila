#! bin/bash

#Downloading and installation of sushi

#download 


git clone https://github.com/tp7/Sushi.git

