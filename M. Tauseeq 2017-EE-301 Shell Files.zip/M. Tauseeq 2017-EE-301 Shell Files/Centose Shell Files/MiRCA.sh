#! bin/bash

#downloading and installation of MiRCA c and c++ based program with pre-requirements

#downloading first


git clone https://github.com/Mkchouk/MiRCA.git



