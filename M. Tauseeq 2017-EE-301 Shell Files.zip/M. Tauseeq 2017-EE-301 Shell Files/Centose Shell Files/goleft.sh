#! bin/bash

#Downloading and installation of Goleft

#download 

sudo apt install gitne https://github.com/brentp/goleft.git

