#! bin/bash

#downloading and installation of seqyclean c and c++ based program

#downloading first


git clone https://github.com/ibest/seqyclean.git




