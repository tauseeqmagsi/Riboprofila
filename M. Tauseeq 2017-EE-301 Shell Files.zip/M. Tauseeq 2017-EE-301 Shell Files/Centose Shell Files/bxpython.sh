#! bin/bash


#Downloading and installation of bx-python

#download 


git clone https://github.com/bxlab/bx-python.git


