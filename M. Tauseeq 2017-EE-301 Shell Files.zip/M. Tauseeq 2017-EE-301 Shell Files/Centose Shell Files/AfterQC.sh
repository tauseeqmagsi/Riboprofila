#! bin/bash

#Downloading and installation of AfterQC

#download 


git clone https://github.com/OpenGene/AfterQC.git




