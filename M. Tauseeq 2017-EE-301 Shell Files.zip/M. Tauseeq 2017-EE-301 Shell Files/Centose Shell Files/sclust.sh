#! bin/bash

#Downloading and installation of sclust

#download 

git clone https://github.com/tapilab/sclust.git


