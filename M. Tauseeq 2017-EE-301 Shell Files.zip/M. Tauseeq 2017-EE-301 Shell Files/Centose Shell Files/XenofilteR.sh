#! bin/bash

#Installation and Downloading of Xenofilter

#software download

git clone https://github.com/PeeperLab/XenofilteR.git


