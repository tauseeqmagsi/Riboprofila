#! bin/bash

#Downloading and installation of shoelaces

#download 


git clone https://github.com/thousandeyes/shoelaces.git


