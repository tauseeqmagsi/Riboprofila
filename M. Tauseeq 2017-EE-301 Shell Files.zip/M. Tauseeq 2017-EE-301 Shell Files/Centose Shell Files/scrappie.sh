#! bin/bash

#downloading and installation of scrappie c and c++ based program

#downloading first


git clone https://github.com/nanoporetech/scrappie.git


