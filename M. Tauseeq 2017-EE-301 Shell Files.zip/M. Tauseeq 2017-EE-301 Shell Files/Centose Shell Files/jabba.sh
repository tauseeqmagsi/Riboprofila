#! bin/bash

#downloading and installation of jabba c and c++ based program with pre-requirements

#downloading first

git clone https://github.com/shyiko/jabba.git

