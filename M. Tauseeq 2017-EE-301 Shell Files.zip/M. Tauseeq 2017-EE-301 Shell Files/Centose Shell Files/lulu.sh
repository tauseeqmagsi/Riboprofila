#! bin/bash

#Installation and Downloading of Lulu

#software download

git clone https://github.com/objective-see/LuLu.git


