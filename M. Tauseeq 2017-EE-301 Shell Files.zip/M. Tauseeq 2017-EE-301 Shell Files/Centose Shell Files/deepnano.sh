#! bin/bash

#Downloading and installation of deepnano

#download 


git clone https://github.com/jeammimi/deepnano.git


