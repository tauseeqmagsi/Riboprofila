#! bin/bash

#downloading and installation of tagdust c and c++ based program

#downloading first

git clone https://github.com/TimoLassmann/tagdust.git


