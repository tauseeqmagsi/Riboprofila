#! bin/bash

#Downloading and installation of deepnano

#download 

sudo apt install git
git clone https://github.com/jeammimi/deepnano.git

#installation of python
#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#pre-requirements

pip install numpy
pip install Cython
pip install h5py
pip install Theano
pip install python-dateutil

#installation of deepnano

/path/deepnano$ OMP_NUM_THREADS=1 python basecall.py <list of fast5 files>



#installation is done but it is specific. we will have to install different packages to use its different features
