#! bin/bash

#downloading and installation of MiRCA c and c++ based program with pre-requirements

#downloading first

sudo apt install git
git clone https://github.com/Mkchouk/MiRCA.git

#install c and c++
#this should be done only once while installing first ever c or c++ tool

sudo apt-get install gcc
sudo apt-get install g++

#pre-requirements

#To install the tool, the user must download the file **MiRCA-master.zip** and extract it in the main directory where software is downloaded

#installation of MiRCA

~/path/MiRCA$ tar -xzf MiRCA-master.zip




#tool gets installed is jabba v0.11.2


