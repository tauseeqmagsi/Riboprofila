#! bin/bash

#Installation and Downloading of Lulu

#software download

sudo apt install git
git clone https://github.com/objective-see/LuLu.git

#Installation of R language--- This should be done when you are installing any R language tool for the first time

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base

sudo -i R

>install.packages('devtools')

>devtools::install_github("objective-see/LuLu.git")

#To Install:
#Simply run the installer application: `LuLu Installer.app`
