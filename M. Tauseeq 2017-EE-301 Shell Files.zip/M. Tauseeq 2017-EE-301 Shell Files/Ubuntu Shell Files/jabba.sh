#! bin/bash

#downloading and installation of jabba c and c++ based program with pre-requirements

#downloading first

sudo apt install git
git clone https://github.com/shyiko/jabba.git

#install c and c++
#this should be done only once while installing first ever c or c++ tool

sudo apt-get install gcc
sudo apt-get install g++

#pre-requirements

sudo apt install curl

#installation of Jabba

curl -sL https://github.com/shyiko/jabba/raw/master/install.sh | bash && . ~/.jabba/jabba.sh

or

~path/Jabba$ curl -sL https://github.com/shyiko/jabba/raw/master/install.sh | bash && . ~/.jabba/jabba.sh



#tool gets installed is jabba v0.11.2


