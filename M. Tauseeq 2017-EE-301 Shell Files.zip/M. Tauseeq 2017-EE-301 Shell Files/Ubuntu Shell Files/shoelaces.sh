#! bin/bash

#Downloading and installation of shoelaces

#download 

sudo apt install git
git clone https://github.com/thousandeyes/shoelaces.git

#installation of python
#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#pre-requirements

sudo apt install go

#installation of shoelaces

go get github.com/thousandeyes/shoelaces
$ cd $GOPATH/src/github.com/thousandeyes/shoelaces
$ go build



#installation is done
