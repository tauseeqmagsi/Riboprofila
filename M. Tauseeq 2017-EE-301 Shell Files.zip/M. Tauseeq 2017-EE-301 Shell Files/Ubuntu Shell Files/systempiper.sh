#! bin/bash

#Installation and Downloading of systemPiper

#The software in R language downloads and installs at a time.

#Installation of R language--- This should be done when you are installing any R language tool for the first time

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base



sudo -i R

>install.packages('devtools')

#for downloading and installation

>devtools::install_github("tgirke/systemPipeR.git")

#To Install packages of systemPiper

> BiocManager::install_command
