#! bin/bash

#Downloading and installation of Goleft

#download 

sudo apt install git
git clone https://github.com/brentp/goleft.git

#installation of python
#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#pre-requirements of softwares

pip install NumPy
pip install scipy
pip install scikit-learn
sudo apt install go

#installation of goleft

go get -u github.com/brentp/goleft/...
go install github.com/brentp/goleft/cmd/goleft


#installation is done here

