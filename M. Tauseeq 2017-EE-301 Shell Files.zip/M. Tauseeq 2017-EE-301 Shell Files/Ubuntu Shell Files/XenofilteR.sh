#! bin/bash

#Installation and Downloading of Xenofilter

#software download

sudo apt install git
git clone https://github.com/PeeperLab/XenofilteR.git

#Installation of R language--- This should be done when you are installing any R language tool for the first time

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base

sudo -i R

>install.packages('devtools')

>devtools::install_github("PeeperLab/XenofilteR.git")


#Installation of XenofilteR should be performed as
#follows:

    > source("http://bioconductor.org/biocLite.R")
    > biocLite(c("Rsamtools", "GenomicAlignments", "BiocParallel", "futile.logger"))

#As the last step in the installation process, the latest XenofilteR package can
#be downloaded from the
#[XenoFilteR releases webpage](https://github.com/PeeperLab/XenoFilteR/releases)
#and installed using the following command:

    $ R CMD INSTALL XenofilteR*.tar.gz
