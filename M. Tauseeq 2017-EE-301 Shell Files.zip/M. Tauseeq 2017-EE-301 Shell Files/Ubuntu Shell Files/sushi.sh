#! bin/bash

#Downloading and installation of sushi

#download 

sudo apt install git
git clone https://github.com/tp7/Sushi.git

#installation of python
#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#pre-requirements

pip install numpy
pip install openCV

#installation of sushi

/Downloads/sushi$ python setup.py build
/Downloads/sushi$ sudo python setup.py install


#installation is done 
