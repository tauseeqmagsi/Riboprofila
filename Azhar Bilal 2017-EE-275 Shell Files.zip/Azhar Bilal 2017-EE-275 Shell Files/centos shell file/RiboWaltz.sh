yum install git 
git clone https://github.com/LabTranslationalArchitectomics/riboWaltz.git


