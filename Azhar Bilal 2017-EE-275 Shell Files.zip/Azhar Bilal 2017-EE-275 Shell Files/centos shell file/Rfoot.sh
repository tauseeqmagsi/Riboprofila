yum install git 
git clone https://github.com/zhejilab/Rfoot.git


