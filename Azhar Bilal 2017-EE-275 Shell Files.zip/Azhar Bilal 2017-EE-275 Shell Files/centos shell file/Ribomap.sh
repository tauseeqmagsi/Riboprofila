yum install git 
git clone https://github.com/Kingsford-Group/ribomap.git


