yum install git
git clone https://github.com/jiangsutx/SRN-Deblur.git



