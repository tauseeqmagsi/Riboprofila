sudo apt install git
git clone https://github.com/DataBiosphere/toil.git

sudo apt-get update 
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#dependencies
pip install python 2.7      
pip install pytorch 0.3.1       
pip install numpy 1.15.2      
pip install scipy 1.1.0     



cd tools/riborl

setup.py file not found
