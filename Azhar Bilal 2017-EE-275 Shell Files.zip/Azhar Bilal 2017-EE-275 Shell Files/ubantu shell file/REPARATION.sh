sudo apt install git
git clone https://github.com/DataBiosphere/toil.git

sudo apt-get update 
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#dependencies
pip install plastid




cd tools/toil
setup.py file not found
