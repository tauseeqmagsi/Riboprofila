sudo apt install git
git clone https://github.com/DataBiosphere/toil.git

sudo apt-get update 
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#dependencies
pip install Python2 
pip install Numpy
pip install Scipy 
pip install Matplotlib 
pip install Statsmodels




cd tools/toil
python setup.py build
sudo python setup.py  install
