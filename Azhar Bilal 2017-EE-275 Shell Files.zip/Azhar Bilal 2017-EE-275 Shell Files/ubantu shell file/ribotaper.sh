sudo apt install git
https://github.com/LabTranslationalArchitectomics/riboWaltz.git


#download 
sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base 


Entering R Base
sudo -i R

install tools

>devtools::install_github('boboppie/RiboTaper')

