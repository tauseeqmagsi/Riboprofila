sudo apt install git
git clone https://github.com/jiangsutx/SRN-Deblur.git

sudo apt-get update 
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#dependencies
pip install Python2.7
 pip install Scipy
 pip install numpy
 pip install Scikit-image



cd tools/toil
setup.py file not found
