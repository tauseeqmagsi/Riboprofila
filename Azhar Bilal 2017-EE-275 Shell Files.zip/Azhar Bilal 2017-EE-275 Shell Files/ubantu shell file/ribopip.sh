sudo apt install git
https://github.com/stepf/RiboPip.git

#download 
sudo apt-get update
sudo apt-get install ruby
ruby --version 


