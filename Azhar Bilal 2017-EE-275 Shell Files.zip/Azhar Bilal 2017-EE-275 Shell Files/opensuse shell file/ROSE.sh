sudo zypper install git
git clone https://github.com/metomi/rose.git


