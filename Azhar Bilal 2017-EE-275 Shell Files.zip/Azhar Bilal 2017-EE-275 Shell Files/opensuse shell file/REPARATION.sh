sudo zypper install git 

git clone https://github.com/DataBiosphere/toil.git 


