sudo zypper install git 
git clone https://github.com/stepf/RiboPip.git



