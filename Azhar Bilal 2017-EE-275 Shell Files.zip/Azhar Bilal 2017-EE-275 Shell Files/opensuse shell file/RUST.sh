sudo zypper install git
git clone https://github.com/rust-lang/rust.git

