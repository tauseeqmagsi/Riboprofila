#! bin/bash

#downloading and installation of fastq-tools c and c++ based program 

#downloading first

sudo apt install git
git clone https://github.com/dcjones/fastq-tools.git

#install c and c++
#this should be done only once while installing first ever c or c++ tool

sudo apt-get install gcc
sudo apt-get install g++

#installation of fastq-tools

/path/fastq-tools$ make



