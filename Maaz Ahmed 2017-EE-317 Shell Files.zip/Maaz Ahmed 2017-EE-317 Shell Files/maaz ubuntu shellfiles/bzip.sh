#downloading and installation of bzip

#downloading first

sudo apt install git
git clone https://github.com/enthought/bzip2-1.0.6.git

only the software is downloded on  ubuntu
