#downloading and installation of gzip

#downloading first

sudo apt install git
git clone https://github.com/Distrotech/gzip.git

only the software is downloded on  ubuntu and no language is specified for this software by referance of omictools.
