#! bin/bash

#downloading and installation of ea-utils c and c++ based program 

#downloading first

sudo apt install git
git clone https://github.com/ExpressionAnalysis/ea-utils.git

#install c and c++
#this should be done only once while installing first ever c or c++ tool

sudo apt-get install gcc
sudo apt-get install g++

#installation of ea-utils

/path/ea-utils$ make



