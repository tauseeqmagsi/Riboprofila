#! bin/bash

#Installation and Downloading of maftools

#software download

sudo apt install git
git clone https://github.com/PoisonAlien/maftools.git

#Installation of R language--- This should be done when you are installing any R language tool for the first time

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base

sudo -i R

>install.packages('devtools')

>devtools::install_github("maftools.git")


#Installation of maftools 
# Installation:

Easy way: Install from [Bioconductor](http://bioconductor.org/packages/release/bioc/html/maftools.html).

```{r}
if (!require("BiocManager"))
    install.packages("BiocManager")
BiocManager::install("maftools")
```

Install from Github for updated features (some of functions from here may not be available on Bioconductor release branch).

```{r results='hide'}
#Install Bioconductor dependencies.
if (!requireNamespace("BiocManager", quietly=TRUE))
    install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")
BiocManager::install("VariantAnnotation")
BiocManager::install("Biostrings")

 #Install  maftools from github repository.
 library("devtools")
install_github(repo = "PoisonAlien/maftools")
```

For full documentation please refer to [vignette](http://bioconductor.org/packages/devel/bioc/vignettes/maftools/inst/doc/maftools.html).

