#Downloading and installation of pysam

#download
sudo apt install git
https://github.com/pysam-developers/pysam.git

#installation of python

#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#preinstallation of pysam

pip install pysam 

#installation of pysam

cd pythontools/pysam/

python setup.py build
sudo python setup.py install

#installation is done here
