#! bin/bash

#downloading and installation of gdc c and c++ based program 

#downloading first

sudo apt install git
git clone https://github.com/D-Programming-GDC/gdc.git

#install c and c++
#this should be done only once while installing first ever c or c++ tool

sudo apt-get install gcc
sudo apt-get install g++

#installation of gdc

/path/gdc$ git submodule





