#downloading and installation of fast-toolkit

#downloading first

sudo apt install git
git clone https://github.com/agordon/fastx_toolkit.git

only the software is downloded on  ubuntu and no language is specified for this software by referance of omictools.
