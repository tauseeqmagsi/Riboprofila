#Downloading and installation of anduril

#download
sudo apt install git
git clone https://github.com/AndurilCSE/Anduril.git

#installation of python

#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#installation of anduril

cd pythontools/andurill/

python setup.py build
sudo python setup.py install

#installation is done here


