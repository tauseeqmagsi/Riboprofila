#Downloading and installation of fastconcat-g

#download
sudo apt install git
github https://github.com/PatrickKueck/FASconCAT-G.git

the software is in pearl language 
