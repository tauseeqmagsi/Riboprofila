#! bin/bash

#Installation and Downloading of Xenofilter

#software download

sudo apt install git
git clone https://github.com/davetang/bedr.git

#Installation of R language--- This should be done when you are installing any R language tool for the first time

sudo apt-get install build-essential libcurl4-gnutls-dev libxml2-dev libssl-dev
sudo apt-get install r-base
sudo apt-get install libopenblas-base r-base

sudo -i R

>install.packages('devtools')

>devtools::install_github("PeeperLab/XenofilteR.git")


#Installation of bedr should be performed as
#follows:
library(devtools)
install_github('davetang/bedr')
library(bedr)

bed_to_granges("test.bed", header = TRUE)

#As the last step in the installation process, the latest bedr package can
#be downloaded from the
#[bedr releases webpage](<http://davetang.org/muse/2015/02/04/bed-granges/>)
#and installed using the following command:

    $ R CMD INSTALL bedr*.tar.gz
