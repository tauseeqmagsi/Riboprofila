#downloading and installation of gff3sort

#downloading first

sudo apt install git
git clone https://github.com/billzt/gff3sort.git

the above software is in pearl language 
