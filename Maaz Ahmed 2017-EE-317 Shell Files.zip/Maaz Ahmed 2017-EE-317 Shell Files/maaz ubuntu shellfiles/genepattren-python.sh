#Downloading and installation of genepattern-python

#download
sudo apt install git
https://github.com/genepattern/genepattern-python.git

#installation of python

#this should be done only once while installing first ever python tool

sudo apt-get update
sudo apt install python
sudo apt install python3
sudo apt install python-minimal
sudo apt install python-pip
sudo apt install python3-pip

#preinstallation of genepattren-python

pip install genepattern-python
pip install genepattern-python--upgrade`


#installation of genepattren-python

cd pythontools/genepattren-python/

python setup.py build
sudo python setup.py install

#installation is done here

