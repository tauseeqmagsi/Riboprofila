#downloading and installation of ubu.wiki

#downloading first

sudo apt install git
git clone https://github.com/mozack/ubu.wiki.git

the above software is in java language 
