#! /bin/bash
#download
sudo apt install git
git clone https://github.com/bmbolstad/affyio.git

the sofware is only downloaded in the centos operating system
