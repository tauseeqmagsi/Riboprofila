#! /bin/bash
#download
sudo apt install git
git clone   https://github.com/genepattern/genepattern-python.git 

the sofware is only downloaded in the centos operating system
