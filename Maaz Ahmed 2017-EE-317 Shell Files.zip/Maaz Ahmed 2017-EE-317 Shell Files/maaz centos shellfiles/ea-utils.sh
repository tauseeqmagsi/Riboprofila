#! /bin/bash
#download
sudo apt install git
git clone https://github.com/ExpressionAnalysis/ea-utils.git

the sofware is only downloaded in the centos operating system
