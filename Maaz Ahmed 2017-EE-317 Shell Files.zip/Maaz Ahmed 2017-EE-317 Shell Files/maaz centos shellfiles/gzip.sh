#! /bin/bash
#download
sudo apt install git
git clone  https://github.com/Distrotech/gzip.git 

the sofware is only downloaded in the centos operating system
